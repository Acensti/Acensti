﻿namespace POSBunifu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.btnInventory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSales = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnUser = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSupplier = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnCategory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPurchasedOrder = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnStockin = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnFindProduct = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnProduct = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnHome = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pnlHeader = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExit = new Bunifu.Framework.UI.BunifuImageButton();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.btnInventory);
            this.bunifuGradientPanel1.Controls.Add(this.btnSales);
            this.bunifuGradientPanel1.Controls.Add(this.btnUser);
            this.bunifuGradientPanel1.Controls.Add(this.btnSupplier);
            this.bunifuGradientPanel1.Controls.Add(this.btnCategory);
            this.bunifuGradientPanel1.Controls.Add(this.btnPurchasedOrder);
            this.bunifuGradientPanel1.Controls.Add(this.btnStockin);
            this.bunifuGradientPanel1.Controls.Add(this.btnFindProduct);
            this.bunifuGradientPanel1.Controls.Add(this.btnProduct);
            this.bunifuGradientPanel1.Controls.Add(this.btnHome);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Red;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(200, 600);
            this.bunifuGradientPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(152, 69);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(7, 87);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(187, 12);
            this.bunifuSeparator1.TabIndex = 1;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // btnInventory
            // 
            this.btnInventory.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnInventory.BackColor = System.Drawing.Color.Transparent;
            this.btnInventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInventory.BorderRadius = 0;
            this.btnInventory.ButtonText = "Inventory Report";
            this.btnInventory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInventory.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnInventory.Iconcolor = System.Drawing.Color.Transparent;
            this.btnInventory.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnInventory.Iconimage")));
            this.btnInventory.Iconimage_right = null;
            this.btnInventory.Iconimage_right_Selected = null;
            this.btnInventory.Iconimage_Selected = null;
            this.btnInventory.IconMarginLeft = 0;
            this.btnInventory.IconMarginRight = 0;
            this.btnInventory.IconRightVisible = true;
            this.btnInventory.IconRightZoom = 0D;
            this.btnInventory.IconVisible = true;
            this.btnInventory.IconZoom = 90D;
            this.btnInventory.IsTab = true;
            this.btnInventory.Location = new System.Drawing.Point(0, 536);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Normalcolor = System.Drawing.Color.Transparent;
            this.btnInventory.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnInventory.OnHoverTextColor = System.Drawing.Color.White;
            this.btnInventory.selected = false;
            this.btnInventory.Size = new System.Drawing.Size(200, 48);
            this.btnInventory.TabIndex = 11;
            this.btnInventory.Text = "Inventory Report";
            this.btnInventory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInventory.Textcolor = System.Drawing.Color.White;
            this.btnInventory.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            // 
            // btnSales
            // 
            this.btnSales.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnSales.BackColor = System.Drawing.Color.Transparent;
            this.btnSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSales.BorderRadius = 0;
            this.btnSales.ButtonText = "Sales Report";
            this.btnSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSales.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnSales.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSales.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSales.Iconimage")));
            this.btnSales.Iconimage_right = null;
            this.btnSales.Iconimage_right_Selected = null;
            this.btnSales.Iconimage_Selected = null;
            this.btnSales.IconMarginLeft = 0;
            this.btnSales.IconMarginRight = 0;
            this.btnSales.IconRightVisible = true;
            this.btnSales.IconRightZoom = 0D;
            this.btnSales.IconVisible = true;
            this.btnSales.IconZoom = 90D;
            this.btnSales.IsTab = true;
            this.btnSales.Location = new System.Drawing.Point(0, 488);
            this.btnSales.Name = "btnSales";
            this.btnSales.Normalcolor = System.Drawing.Color.Transparent;
            this.btnSales.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnSales.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSales.selected = false;
            this.btnSales.Size = new System.Drawing.Size(200, 48);
            this.btnSales.TabIndex = 10;
            this.btnSales.Text = "Sales Report";
            this.btnSales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSales.Textcolor = System.Drawing.Color.White;
            this.btnSales.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSales.Click += new System.EventHandler(this.btnSales_Click);
            // 
            // btnUser
            // 
            this.btnUser.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnUser.BackColor = System.Drawing.Color.Transparent;
            this.btnUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUser.BorderRadius = 0;
            this.btnUser.ButtonText = "Manage Users";
            this.btnUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUser.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnUser.Iconcolor = System.Drawing.Color.Transparent;
            this.btnUser.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnUser.Iconimage")));
            this.btnUser.Iconimage_right = null;
            this.btnUser.Iconimage_right_Selected = null;
            this.btnUser.Iconimage_Selected = null;
            this.btnUser.IconMarginLeft = 0;
            this.btnUser.IconMarginRight = 0;
            this.btnUser.IconRightVisible = true;
            this.btnUser.IconRightZoom = 0D;
            this.btnUser.IconVisible = true;
            this.btnUser.IconZoom = 90D;
            this.btnUser.IsTab = true;
            this.btnUser.Location = new System.Drawing.Point(0, 440);
            this.btnUser.Name = "btnUser";
            this.btnUser.Normalcolor = System.Drawing.Color.Transparent;
            this.btnUser.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnUser.OnHoverTextColor = System.Drawing.Color.White;
            this.btnUser.selected = false;
            this.btnUser.Size = new System.Drawing.Size(200, 48);
            this.btnUser.TabIndex = 8;
            this.btnUser.Text = "Manage Users";
            this.btnUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUser.Textcolor = System.Drawing.Color.White;
            this.btnUser.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUser.Click += new System.EventHandler(this.btnUser_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnSupplier.BackColor = System.Drawing.Color.Transparent;
            this.btnSupplier.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSupplier.BorderRadius = 0;
            this.btnSupplier.ButtonText = "Manage Supplier";
            this.btnSupplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSupplier.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnSupplier.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSupplier.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSupplier.Iconimage")));
            this.btnSupplier.Iconimage_right = null;
            this.btnSupplier.Iconimage_right_Selected = null;
            this.btnSupplier.Iconimage_Selected = null;
            this.btnSupplier.IconMarginLeft = 0;
            this.btnSupplier.IconMarginRight = 0;
            this.btnSupplier.IconRightVisible = true;
            this.btnSupplier.IconRightZoom = 0D;
            this.btnSupplier.IconVisible = true;
            this.btnSupplier.IconZoom = 90D;
            this.btnSupplier.IsTab = true;
            this.btnSupplier.Location = new System.Drawing.Point(0, 392);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Normalcolor = System.Drawing.Color.Transparent;
            this.btnSupplier.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnSupplier.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSupplier.selected = false;
            this.btnSupplier.Size = new System.Drawing.Size(200, 48);
            this.btnSupplier.TabIndex = 7;
            this.btnSupplier.Text = "Manage Supplier";
            this.btnSupplier.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSupplier.Textcolor = System.Drawing.Color.White;
            this.btnSupplier.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // btnCategory
            // 
            this.btnCategory.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnCategory.BackColor = System.Drawing.Color.Transparent;
            this.btnCategory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCategory.BorderRadius = 0;
            this.btnCategory.ButtonText = "Manage Category";
            this.btnCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCategory.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnCategory.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCategory.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCategory.Iconimage")));
            this.btnCategory.Iconimage_right = null;
            this.btnCategory.Iconimage_right_Selected = null;
            this.btnCategory.Iconimage_Selected = null;
            this.btnCategory.IconMarginLeft = 0;
            this.btnCategory.IconMarginRight = 0;
            this.btnCategory.IconRightVisible = true;
            this.btnCategory.IconRightZoom = 0D;
            this.btnCategory.IconVisible = true;
            this.btnCategory.IconZoom = 90D;
            this.btnCategory.IsTab = true;
            this.btnCategory.Location = new System.Drawing.Point(0, 344);
            this.btnCategory.Name = "btnCategory";
            this.btnCategory.Normalcolor = System.Drawing.Color.Transparent;
            this.btnCategory.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnCategory.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCategory.selected = false;
            this.btnCategory.Size = new System.Drawing.Size(200, 48);
            this.btnCategory.TabIndex = 6;
            this.btnCategory.Text = "Manage Category";
            this.btnCategory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCategory.Textcolor = System.Drawing.Color.White;
            this.btnCategory.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCategory.Click += new System.EventHandler(this.btnCategory_Click);
            // 
            // btnPurchasedOrder
            // 
            this.btnPurchasedOrder.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnPurchasedOrder.BackColor = System.Drawing.Color.Transparent;
            this.btnPurchasedOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPurchasedOrder.BorderRadius = 0;
            this.btnPurchasedOrder.ButtonText = "Purchase Order";
            this.btnPurchasedOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPurchasedOrder.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnPurchasedOrder.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPurchasedOrder.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnPurchasedOrder.Iconimage")));
            this.btnPurchasedOrder.Iconimage_right = null;
            this.btnPurchasedOrder.Iconimage_right_Selected = null;
            this.btnPurchasedOrder.Iconimage_Selected = null;
            this.btnPurchasedOrder.IconMarginLeft = 0;
            this.btnPurchasedOrder.IconMarginRight = 0;
            this.btnPurchasedOrder.IconRightVisible = true;
            this.btnPurchasedOrder.IconRightZoom = 0D;
            this.btnPurchasedOrder.IconVisible = true;
            this.btnPurchasedOrder.IconZoom = 90D;
            this.btnPurchasedOrder.IsTab = true;
            this.btnPurchasedOrder.Location = new System.Drawing.Point(0, 296);
            this.btnPurchasedOrder.Name = "btnPurchasedOrder";
            this.btnPurchasedOrder.Normalcolor = System.Drawing.Color.Transparent;
            this.btnPurchasedOrder.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnPurchasedOrder.OnHoverTextColor = System.Drawing.Color.White;
            this.btnPurchasedOrder.selected = false;
            this.btnPurchasedOrder.Size = new System.Drawing.Size(200, 48);
            this.btnPurchasedOrder.TabIndex = 5;
            this.btnPurchasedOrder.Text = "Purchase Order";
            this.btnPurchasedOrder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPurchasedOrder.Textcolor = System.Drawing.Color.White;
            this.btnPurchasedOrder.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchasedOrder.Click += new System.EventHandler(this.btnPurchasedOrder_Click);
            // 
            // btnStockin
            // 
            this.btnStockin.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnStockin.BackColor = System.Drawing.Color.Transparent;
            this.btnStockin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStockin.BorderRadius = 0;
            this.btnStockin.ButtonText = "Stockin";
            this.btnStockin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStockin.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnStockin.Iconcolor = System.Drawing.Color.Transparent;
            this.btnStockin.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnStockin.Iconimage")));
            this.btnStockin.Iconimage_right = null;
            this.btnStockin.Iconimage_right_Selected = null;
            this.btnStockin.Iconimage_Selected = null;
            this.btnStockin.IconMarginLeft = 0;
            this.btnStockin.IconMarginRight = 0;
            this.btnStockin.IconRightVisible = true;
            this.btnStockin.IconRightZoom = 0D;
            this.btnStockin.IconVisible = true;
            this.btnStockin.IconZoom = 90D;
            this.btnStockin.IsTab = true;
            this.btnStockin.Location = new System.Drawing.Point(0, 248);
            this.btnStockin.Name = "btnStockin";
            this.btnStockin.Normalcolor = System.Drawing.Color.Transparent;
            this.btnStockin.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnStockin.OnHoverTextColor = System.Drawing.Color.White;
            this.btnStockin.selected = false;
            this.btnStockin.Size = new System.Drawing.Size(200, 48);
            this.btnStockin.TabIndex = 4;
            this.btnStockin.Text = "Stockin";
            this.btnStockin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStockin.Textcolor = System.Drawing.Color.White;
            this.btnStockin.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStockin.Click += new System.EventHandler(this.btnStockin_Click);
            // 
            // btnFindProduct
            // 
            this.btnFindProduct.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnFindProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnFindProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFindProduct.BorderRadius = 0;
            this.btnFindProduct.ButtonText = "Search Products";
            this.btnFindProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFindProduct.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnFindProduct.Iconcolor = System.Drawing.Color.Transparent;
            this.btnFindProduct.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnFindProduct.Iconimage")));
            this.btnFindProduct.Iconimage_right = null;
            this.btnFindProduct.Iconimage_right_Selected = null;
            this.btnFindProduct.Iconimage_Selected = null;
            this.btnFindProduct.IconMarginLeft = 0;
            this.btnFindProduct.IconMarginRight = 0;
            this.btnFindProduct.IconRightVisible = true;
            this.btnFindProduct.IconRightZoom = 0D;
            this.btnFindProduct.IconVisible = true;
            this.btnFindProduct.IconZoom = 90D;
            this.btnFindProduct.IsTab = true;
            this.btnFindProduct.Location = new System.Drawing.Point(0, 200);
            this.btnFindProduct.Name = "btnFindProduct";
            this.btnFindProduct.Normalcolor = System.Drawing.Color.Transparent;
            this.btnFindProduct.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnFindProduct.OnHoverTextColor = System.Drawing.Color.White;
            this.btnFindProduct.selected = false;
            this.btnFindProduct.Size = new System.Drawing.Size(200, 48);
            this.btnFindProduct.TabIndex = 3;
            this.btnFindProduct.Text = "Search Products";
            this.btnFindProduct.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFindProduct.Textcolor = System.Drawing.Color.White;
            this.btnFindProduct.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindProduct.Click += new System.EventHandler(this.btnFindProduct_Click);
            // 
            // btnProduct
            // 
            this.btnProduct.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProduct.BorderRadius = 0;
            this.btnProduct.ButtonText = "Products";
            this.btnProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProduct.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnProduct.Iconcolor = System.Drawing.Color.Transparent;
            this.btnProduct.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnProduct.Iconimage")));
            this.btnProduct.Iconimage_right = null;
            this.btnProduct.Iconimage_right_Selected = null;
            this.btnProduct.Iconimage_Selected = null;
            this.btnProduct.IconMarginLeft = 0;
            this.btnProduct.IconMarginRight = 0;
            this.btnProduct.IconRightVisible = true;
            this.btnProduct.IconRightZoom = 0D;
            this.btnProduct.IconVisible = true;
            this.btnProduct.IconZoom = 90D;
            this.btnProduct.IsTab = true;
            this.btnProduct.Location = new System.Drawing.Point(0, 152);
            this.btnProduct.Name = "btnProduct";
            this.btnProduct.Normalcolor = System.Drawing.Color.Transparent;
            this.btnProduct.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnProduct.OnHoverTextColor = System.Drawing.Color.White;
            this.btnProduct.selected = false;
            this.btnProduct.Size = new System.Drawing.Size(200, 48);
            this.btnProduct.TabIndex = 2;
            this.btnProduct.Text = "Products";
            this.btnProduct.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProduct.Textcolor = System.Drawing.Color.White;
            this.btnProduct.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProduct.Click += new System.EventHandler(this.btnProduct_Click);
            // 
            // btnHome
            // 
            this.btnHome.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnHome.BackColor = System.Drawing.Color.Transparent;
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHome.BorderRadius = 0;
            this.btnHome.ButtonText = "Home";
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnHome.Iconcolor = System.Drawing.Color.Transparent;
            this.btnHome.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnHome.Iconimage")));
            this.btnHome.Iconimage_right = null;
            this.btnHome.Iconimage_right_Selected = null;
            this.btnHome.Iconimage_Selected = null;
            this.btnHome.IconMarginLeft = 0;
            this.btnHome.IconMarginRight = 0;
            this.btnHome.IconRightVisible = true;
            this.btnHome.IconRightZoom = 0D;
            this.btnHome.IconVisible = true;
            this.btnHome.IconZoom = 90D;
            this.btnHome.IsTab = true;
            this.btnHome.Location = new System.Drawing.Point(0, 104);
            this.btnHome.Name = "btnHome";
            this.btnHome.Normalcolor = System.Drawing.Color.Transparent;
            this.btnHome.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.btnHome.OnHoverTextColor = System.Drawing.Color.White;
            this.btnHome.selected = true;
            this.btnHome.Size = new System.Drawing.Size(200, 48);
            this.btnHome.TabIndex = 1;
            this.btnHome.Text = "Home";
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Textcolor = System.Drawing.Color.White;
            this.btnHome.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlHeader.BackgroundImage")));
            this.pnlHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlHeader.Controls.Add(this.bunifuImageButton3);
            this.pnlHeader.Controls.Add(this.bunifuImageButton2);
            this.pnlHeader.Controls.Add(this.bunifuImageButton1);
            this.pnlHeader.Controls.Add(this.label1);
            this.pnlHeader.Controls.Add(this.btnExit);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.pnlHeader.GradientBottomRight = System.Drawing.Color.Red;
            this.pnlHeader.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(23)))), ((int)(((byte)(20)))));
            this.pnlHeader.GradientTopRight = System.Drawing.Color.Red;
            this.pnlHeader.Location = new System.Drawing.Point(200, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Quality = 10;
            this.pnlHeader.Size = new System.Drawing.Size(809, 33);
            this.pnlHeader.TabIndex = 1;
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.Image")));
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.Location = new System.Drawing.Point(6, 0);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(41, 30);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton3.TabIndex = 4;
            this.bunifuImageButton3.TabStop = false;
            this.bunifuImageButton3.Zoom = 10;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(672, 1);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(41, 30);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 3;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(719, 1);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(41, 30);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 2;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(53, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Point of Sales ";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageActive = null;
            this.btnExit.Location = new System.Drawing.Point(766, 1);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(41, 30);
            this.btnExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnExit.TabIndex = 0;
            this.btnExit.TabStop = false;
            this.btnExit.Zoom = 10;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pnlContainer
            // 
            this.pnlContainer.BackColor = System.Drawing.Color.White;
            this.pnlContainer.Location = new System.Drawing.Point(206, 39);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(796, 549);
            this.pnlContainer.TabIndex = 2;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.pnlHeader;
            this.bunifuDragControl1.Vertical = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(15)))), ((int)(((byte)(13)))));
            this.ClientSize = new System.Drawing.Size(1009, 600);
            this.Controls.Add(this.pnlContainer);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuFlatButton btnHome;
        private Bunifu.Framework.UI.BunifuFlatButton btnStockin;
        private Bunifu.Framework.UI.BunifuFlatButton btnFindProduct;
        private Bunifu.Framework.UI.BunifuFlatButton btnProduct;
        private Bunifu.Framework.UI.BunifuFlatButton btnInventory;
        private Bunifu.Framework.UI.BunifuFlatButton btnSales;
        private Bunifu.Framework.UI.BunifuFlatButton btnUser;
        private Bunifu.Framework.UI.BunifuFlatButton btnSupplier;
        private Bunifu.Framework.UI.BunifuFlatButton btnCategory;
        private Bunifu.Framework.UI.BunifuFlatButton btnPurchasedOrder;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuGradientPanel pnlHeader;
        private System.Windows.Forms.Panel pnlContainer;
        private Bunifu.Framework.UI.BunifuImageButton btnExit;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
    }
}

